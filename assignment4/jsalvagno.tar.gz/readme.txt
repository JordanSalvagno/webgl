move player with left and right arrow keys and fire with space.
shoot the aliens before they reach you.
shields protect you from alien fire, which isn't included at the moment.
you can shoot up throught your shields to tactically eliminate aliens.
